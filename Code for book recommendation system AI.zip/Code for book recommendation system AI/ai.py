import numpy as np 
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn import neighbors
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
df = pd.read_csv('/content/bestsellers with categories.csv',error_bad_lines = False)
df.head(10)
top_ten = df[df['Reviews'] > 10000]
top_ten.sort_values(by='User Rating', ascending=False)
plt.style.use('seaborn-whitegrid')
plt.figure(figsize=(10, 10))
data = top_ten.sort_values(by='User Rating', ascending=False).head(30)
sns.barplot(x="User Rating", y="Name", data=data, palette='inferno')
import seaborn as sns
import matplotlib.pyplot as plt

most_books = df.groupby('Author')['Name'].count().reset_index().sort_values('Name', ascending=False).head(10).set_index('Author')

plt.figure(figsize=(15,10))
ax = sns.barplot(x=most_books['Name'], y=most_books.index, palette='inferno')

ax.set_title("Top 10 authors with most books")
ax.set_xlabel("Total number of books")

totals = []
for i in ax.patches:
    totals.append(i.get_width())

total = sum(totals)

for i in ax.patches:
    ax.text(i.get_width()+.2, i.get_y()+.2, str(round(i.get_width())), fontsize=15, color='black')

plt.show()
import seaborn as sns
import matplotlib.pyplot as plt

most_rated = df.sort_values('Reviews', ascending=False).head(10).set_index('Name')

plt.figure(figsize=(15,10))
ax = sns.barplot(x=most_rated['Reviews'], y=most_rated.index, palette='inferno')

totals = []
for i in ax.patches:
    totals.append(i.get_width())

total = sum(totals)

for i in ax.patches:
    ax.text(i.get_width()+.2, i.get_y()+.2, str(round(i.get_width())), fontsize=15, color='black')

plt.show()
df['User Rating'] = df['User Rating'].astype(float)

fig, ax = plt.subplots(figsize=[15,10])
sns.histplot(df['User Rating'], ax=ax)
ax.set_title('Average rating distribution for all books', fontsize=20)
ax.set_xlabel('Average rating', fontsize=13)
ax = sns.relplot(data=df, x="User Rating", y="Reviews", color = 'red', sizes=(100, 200), height=7, marker='o')
plt.title("Relation between Rating counts and Average Ratings",fontsize = 15)
ax.set_axis_labels("Average Rating", "Ratings Count")
df2 = df.copy()
df2.loc[ (df2['User Rating'] >= 0) & (df2['User Rating'] <= 1), 'rating_between'] = "between 0 and 1"
df2.loc[ (df2['User Rating'] > 1) & (df2['User Rating'] <= 2), 'rating_between'] = "between 1 and 2"
df2.loc[ (df2['User Rating'] > 2) & (df2['User Rating'] <= 3), 'rating_between'] = "between 2 and 3"
df2.loc[ (df2['User Rating'] > 3) & (df2['User Rating'] <= 4), 'rating_between'] = "between 3 and 4"
df2.loc[ (df2['User Rating'] > 4) & (df2['User Rating'] <= 5), 'rating_between'] = "between 4 and 5"
rating_df = pd.get_dummies(df2['rating_between'])
features = pd.concat([rating_df,  
                      df2['User Rating'], 
                      df2['Reviews']], axis=1)
from sklearn.preprocessing import MinMaxScaler
min_max_scaler = MinMaxScaler()
features = min_max_scaler.fit_transform(features)
model = neighbors.NearestNeighbors(n_neighbors=6, algorithm='ball_tree')
model.fit(features)
dist, idlist = model.kneighbors(features)
def BookRecommender(book_name):
    book_list_name = []
    book_id = df2[df2['Name'] == book_name].index
    book_id = book_id[0]
    for newid in idlist[book_id]:
        book_list_name.append(df2.loc[newid].Name)
    return book_list_name
    
BookNames = BookRecommender('A Game of Thrones / A Clash of Kings / A Storm of Swords / A Feast of Crows / A Dance with Dragons')
BookNames

